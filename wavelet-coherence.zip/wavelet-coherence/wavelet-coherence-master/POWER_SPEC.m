% Add the toolbox to the path (adjust path as needed)
addpath('D:/@sem_2_mtech/climate data analysis/@CDA_project_new\wavelet-coherence/wavelet-coherence-master');


data = readmatrix("D:/@sem_2_mtech/climate data analysis/@CDA_project_new/sea_ice_concentration_difference.csv");
%"D:/@sem_2_mtech/climate data analysis/@CDA_PROJECT/CDA_DATA_deseasonalized.csv"

% Time vector
time = data(:, 1);

% Define variable names and corresponding data columns
variableNames = {'Central Arctic', 'Chukchi Sea', 'East Siberian Sea', ...
           'Beaufort Sea', 'Canadian Archipelago', 'Laptev Sea', ...
           'Kara Sea', 'Barents Sea'};

variableData = data(:, 7:14);  % All columns except time

% Loop through each variable and plot spectral power
for i = 1:length(variableNames)
    plot_spectral_power(time, variableData(:, i), variableNames{i});
end
function plot_spectral_power(t, x, plotTitle)
    dt = mean(diff(t));
    x = detrend(x);
    N = length(x);
    fs = 1/dt;

    fft_x = fft(x);
    psd = abs(fft_x).^2 / (N * fs);
    psd = psd(1:floor(N/2)+1);
    freq = (0:floor(N/2)) * (fs/N);

    % Remove zero frequency to avoid division by zero in period
    freq_nozero = freq(2:end);
    psd_nozero = psd(2:end);
    period_nozero = 1 ./ freq_nozero;

    % Calculate lag-1 autocorrelation (rho)
    x1 = x(1:end-1);
    x2 = x(2:end);
    rho = sum((x1 - mean(x1)) .* (x2 - mean(x2))) / sum((x1 - mean(x1)).^2);

    % Estimate theoretical AR(1) spectrum
    theorAR = (1 - rho^2) ./ (1 + rho^2 - 2*rho*cos(2*pi*freq_nozero*dt));
    theorAR = theorAR * mean(psd_nozero);

    % Confidence levels (chi-squared, DOF=2)
    chi2_90 = theorAR * 4.605 / 2;
    chi2_95 = theorAR * 5.991 / 2;

    % Plot
    figure('Color', 'w', 'Name', ['Spectral Power - ' plotTitle]);
    hold on;
    plot(freq_nozero, psd_nozero, 'k', 'LineWidth', 1.2);
    plot(freq_nozero, theorAR, 'r', 'LineWidth', 1.2);
    plot(freq_nozero, chi2_90, 'g--', 'LineWidth', 1);
    plot(freq_nozero, chi2_95, 'b--', 'LineWidth', 1);
    hold off;

    xlabel('Frequency [1/year]');
    ylabel('Spectral Power');
    title(['Spectral Power: ', plotTitle]);
    legend('Spectral Power', 'AR(1)', '90% CI', '95% CI', 'Location', 'northeast');
    xlim([0 7]);
    grid on;

    % Find local maxima in the PSD (excluding first and last points)
    N_peaks = 7;
    locs = find((psd_nozero(2:end-1) > psd_nozero(1:end-2)) & (psd_nozero(2:end-1) > psd_nozero(3:end)));
    locs = locs + 1; % adjust indices

    % Sort and pick top N_peaks
    [~, sorted_idx] = sort(psd_nozero(locs), 'descend');
    top_locs = locs(sorted_idx(1:min(N_peaks, length(locs))));

    % Label peaks with period values (no markers)
    hold on;
    for i = 1:length(top_locs)
        text(freq_nozero(top_locs(i)), psd_nozero(top_locs(i)), ...
            sprintf('%.2f', period_nozero(top_locs(i))), ...
            'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'center', ...
            'FontSize', 8, 'Color', 'red', 'FontWeight', 'bold');
    end
    hold off;

end