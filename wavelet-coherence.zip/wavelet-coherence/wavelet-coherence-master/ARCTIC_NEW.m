% Add the toolbox to the path (adjust path as needed)
addpath('D:/@sem_2_mtech/climate data analysis/@CDA_project_new\wavelet-coherence/wavelet-coherence-master');


data = readmatrix("D:/@sem_2_mtech/climate data analysis/@CDA_project_new/sea_ice_concentration_difference.csv");
%"D:/@sem_2_mtech/climate data analysis/@CDA_PROJECT/CDA_DATA_deseasonalized.csv"


time = data(:, 1); %TIME
SIC = data(:, 2);% SEA ICE CONCENTRATION
nao = data(:, 3);      % NAO index
ao = data(:, 4);       % AO index
enso = data(:, 5); % ENSO index
ssrd = data(:,6); % solar_radiation
CA = data(:,7); %Central Arctic
CHU_SEA = data(:,8);%Chukchi Sea
ES_SEA = data(:,9);%East Siberian Sea
Beaufort_Sea = data(:,10);%Beaufort Sea
Canadian_Archipelago = data(:,11);%Canadian Archipelago
Laptev_Sea = data(:,12);%Laptev Sea
Kara_Sea = data(:,13);%Kara Sea
Barents_Sea = data(:,14);%Barents Sea
% 
% d_sic = [time SIC];
% d_extent = [time extent];
% d_nao = [time nao];
% d_ao = [time ao];
% d_enso = [time enso];
% rainfall
% figure('Color', [1 1 1], 'Name', 'CWT - JJAS Rainfall');
% wt([time rainfall]);
% title('JJAS Rainfall');


% % Sea Ice Concentration
% figure('Color', [1 1 1], 'Name', 'CWT - SIC Chukchi Sea');
% wt([time CA]);
% title('Chukchi Sea');
% % 
% % Sea Ice Extent
% figure('Color', [1 1 1], 'Name', 'CWT - Sea Ice Extent');
% wt([time extent]);
% title('Sea Ice Extent');
% 
% % NAO Index
% figure('Color', [1 1 1], 'Name', 'CWT - NAO');
% wt([time nao]);
% title('NAO Index');
% 
% % AO Index
% figure('Color', [1 1 1], 'Name', 'CWT - AO');
% wt([time ao]);
% title('AO Index');

% % ENSO Index
% figure('Color', [1 1 1], 'Name', 'CWT - ENSO');
% wt([time enso]);
% title('ENSO Index');

% % SSRD Index
% figure('Color', [1 1 1], 'Name', 'CWT - SSRD');
% wt([time ssrd]);
% title('SSRD Index');



% % XWT: SIC vs NAO
% figure('Color', [1 1 1], 'Name', 'XWT - SIC vs NAO');
% xwt([time SIC], [time nao]);
% title('XWT - Sea Ice Concentration vs NAO');
% 
% % XWT: SIC vs AO
% figure('Color', [1 1 1], 'Name', 'XWT - SIC vs AO');
% xwt([time SIC], [time ao]);
% title('XWT - Sea Ice Concentration vs AO');
% 
% % XWT: SIC vs ENSO
% figure('Color', [1 1 1], 'Name', 'XWT - SIC vs ENSO');
% xwt([time SIC], [time enso]);
% title('XWT - Sea Ice Concentration vs ENSO');
% 
% % XWT: SIC vs Sea Ice Extent (optional)
% figure('Color', [1 1 1], 'Name', 'XWT - SIC vs Sea Ice Extent');
% xwt([time SIC], [time extent]);
% title('XWT - Sea Ice Concentration vs Sea Ice Extent');

% % XWT: SIC vs Sea Ice Extent (optional)
% figure('Color', [1 1 1], 'Name', 'XWT - SIC vs SSRD');
% xwt([time SIC], [time ssrd]);
% title('XWT - Sea Ice Concentration vs Solar Radiation');

% figure('Color', [1 1 1], 'Name', 'WTC - SIC vs AO');
% wtc([time SIC], [time ao]);
% title('WTC - Sea Ice Concentration vs AO');
% 
% figure('Color', [1 1 1], 'Name', 'WTC - SIC vs NAO');
% wtc([time SIC], [time nao]);
% title('WTC - Sea Ice Concentration vs NAO');
% 
% figure('Color', [1 1 1], 'Name', 'WTC - SIC vs NAO');
% wtc([time SIC], [time enso]);
% title('WTC - Sea Ice Concentration vs ENSO');

% figure('Color', [1 1 1], 'Name', 'WTC - SIC vs NAO');
% wtc([time SIC], [time extent]);
% title('WTC - Sea Ice Concentration vs Sea Ice Extent ');

% figure('Color', [1 1 1], 'Name', 'WTC - SIC vs SSRD');
% wtc([time SIC], [time ssrd]);
% title('WTC - Sea Ice Concentration vs Solar radiation ');

% figure('Color', [1 1 1], 'Name', 'WTC - Rainfall vs NINA34');
% wtc([time rainfall], [time nina]);
% title('WTC - Rainfall vs NINa34 ');


% % Extract variables from data
% time = data(:, 1); % TIME
% CA = data(:,7); % Central Arctic
% CHU_SEA = data(:,8); % Chukchi Sea
% ES_SEA = data(:,9); % East Siberian Sea
% Beaufort_Sea = data(:,10); % Beaufort Sea
% Canadian_Archipelago = data(:,11); % Canadian Archipelago
% Laptev_Sea = data(:,12); % Laptev Sea
% Kara_Sea = data(:,13); % Kara Sea
% Barents_Sea = data(:,14); % Barents Sea
% 
% % Region names and data
% regions = {'Central Arctic', 'Chukchi Sea', 'East Siberian Sea', ...
%            'Beaufort Sea', 'Canadian Archipelago', 'Laptev Sea', ...
%            'Kara Sea', 'Barents Sea'};
% 
% region_data = {CA, CHU_SEA, ES_SEA, Beaufort_Sea, ...
%                Canadian_Archipelago, Laptev_Sea, ...
%                Kara_Sea, Barents_Sea};
% 
% % Plot each region in a separate figure
% for i = 1:8
%     figure('Color', [1 1 1], 'Name', ['CWT - ' regions{i}]);
%     wt([time, region_data{i}]);  % Or use: wt(region_data{i}, 'Time', time);
%     title(regions{i});
% end

% % Extract time and variables
% time = data(:, 1);           % TIME
% nao = data(:, 3);            % NAO index
% ao = data(:, 4);             % AO index
% enso = data(:, 5);           % ENSO index
% ssrd = data(:, 6);           % Solar radiation
% 
% % Sea Ice Concentration regions
% regions = {'Central Arctic', 'Chukchi Sea', 'East Siberian Sea', ...
%            'Beaufort Sea', 'Canadian Archipelago', 'Laptev Sea', ...
%            'Kara Sea', 'Barents Sea'};
% 
% region_data = {data(:,7), data(:,8), data(:,9), data(:,10), ...
%                data(:,11), data(:,12), data(:,13), data(:,14)};
% 
% % Climate indices
% indices = {'NAO', 'AO', 'ENSO', 'SSRD'};
% index_data = {nao, ao, enso, ssrd};
% 
% % Loop over each region and index combination
% for i = 1:length(regions)
%     for j = 1:length(indices)
%         figure('Color', [1 1 1], ...
%                'Name', ['XWT - ' regions{i} ' vs ' indices{j}]);
% 
%         % Perform XWT
%         xwt([time region_data{i}], [time index_data{j}]);
% 
%         % Set title
%         title(['XWT - ' regions{i} ' vs ' indices{j}]);
% 
%         % Save the figure as PNG
%         clean_region = strrep(regions{i}, ' ', '_'); % replace spaces with underscores
%         clean_index = strrep(indices{j}, ' ', '_');
%         filename = ['XWT_' clean_region '_vs_' clean_index '.png'];
%         saveas(gcf, filename);
%     end
% end


% Extract time and variables
time = data(:, 1);           % TIME
nao = data(:, 3);            % NAO index
ao = data(:, 4);             % AO index
enso = data(:, 5);           % ENSO index
ssrd = data(:, 6);           % Solar radiation

% Sea Ice Concentration regions
regions = {'Central Arctic', 'Chukchi Sea', 'East Siberian Sea', ...
           'Beaufort Sea', 'Canadian Archipelago', 'Laptev Sea', ...
           'Kara Sea', 'Barents Sea'};

region_data = {data(:,7), data(:,8), data(:,9), data(:,10), ...
               data(:,11), data(:,12), data(:,13), data(:,14)};

% Climate indices
indices = {'NAO', 'AO', 'ENSO', 'SSRD'};
index_data = {nao, ao, enso, ssrd};

% Loop over each region and index combination for WTC
for i = 1:length(regions)
    for j = 1:length(indices)
        figure('Color', [1 1 1], ...
               'Name', ['WTC - ' regions{i} ' vs ' indices{j}]);

        % Perform WTC
        wtc([time region_data{i}], [time index_data{j}]);

        % Set title
        title(['WTC - ' regions{i} ' vs ' indices{j}]);

        % Save the figure as PNG
        clean_region = strrep(regions{i}, ' ', '_');
        clean_index = strrep(indices{j}, ' ', '_');
        filename = ['WTC_' clean_region '_vs_' clean_index '.png'];
        saveas(gcf, filename);
    end
end













