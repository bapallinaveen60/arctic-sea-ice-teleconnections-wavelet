% Add any required toolbox paths if needed (optional)
% addpath('D:/path/to/wavelet-coherence/wavelet-coherence-master');
addpath('D:/@sem_2_mtech/climate data analysis/@CDA_project_new\wavelet-coherence/wavelet-coherence-master');
% Read data
data = readmatrix("D:/@sem_2_mtech/climate data analysis/@CDA_project_new/sea_ice_concentration_difference.csv");

% Time vector (column 1)
time = data(:, 1);

% Region-specific data (columns 7 to 14)
regionData = data(:, 7:14);

% Region names corresponding to each column
regionNames = {'Central Arctic', 'Chukchi Sea', 'East Siberian Sea', ...
               'Beaufort Sea', 'Canadian Archipelago', 'Laptev Sea', ...
               'Kara Sea', 'Barents Sea'};

% Loop over each region and generate plots
for i = 1:length(regionNames)
    fig = plot_spectral_power(time, regionData(:, i), regionNames{i});

    % Create filename and save as PNG
    filename = sprintf('spectral_power_%s.png', strrep(regionNames{i}, ' ', '_'));
    saveas(fig, filename);

    % Close the figure to save memory
    close(fig);
end

% --- Function to compute and plot spectral power ---
function fig = plot_spectral_power(t, x, plotTitle)
    dt = mean(diff(t));
    x = detrend(x);             % Remove linear trend
    N = length(x);
    fs = 1/dt;                  % Sampling frequency

    % FFT and Power Spectral Density
    fft_x = fft(x);
    psd = abs(fft_x).^2 / (N * fs);
    psd = psd(1:floor(N/2)+1);
    freq = (0:floor(N/2)) * (fs/N);

    % Remove zero frequency
    freq_nozero = freq(2:end);
    psd_nozero = psd(2:end);
    period_nozero = 1 ./ freq_nozero;

    % AR(1) theoretical spectrum
    x1 = x(1:end-1);
    x2 = x(2:end);
    rho = sum((x1 - mean(x1)) .* (x2 - mean(x2))) / sum((x1 - mean(x1)).^2);
    theorAR = (1 - rho^2) ./ (1 + rho^2 - 2*rho*cos(2*pi*freq_nozero*dt));
    theorAR = theorAR * mean(psd_nozero);

    % Confidence intervals (DOF=2)
    chi2_90 = theorAR * 4.605 / 2;
    chi2_95 = theorAR * 5.991 / 2;

    % Create figure (invisible for saving only)
    fig = figure('Color', 'w', 'Visible', 'off');
    hold on;
    plot(freq_nozero, psd_nozero, 'k', 'LineWidth', 1.2);
    plot(freq_nozero, theorAR, 'r', 'LineWidth', 1.2);
    plot(freq_nozero, chi2_90, 'g--', 'LineWidth', 1);
    plot(freq_nozero, chi2_95, 'b--', 'LineWidth', 1);
    hold off;

    xlabel('Frequency [1/year]');
    ylabel('Spectral Power');
    title(['Spectral Power: ', plotTitle], 'Interpreter', 'none');
    legend('Spectral Power', 'AR(1)', '90% CI', '95% CI', 'Location', 'northeast');
    xlim([0 5]);
    grid on;

    % Find and label peak periods
    N_peaks = 5;
    locs = find((psd_nozero(2:end-1) > psd_nozero(1:end-2)) & ...
                (psd_nozero(2:end-1) > psd_nozero(3:end))) + 1;

    [~, sorted_idx] = sort(psd_nozero(locs), 'descend');
    top_locs = locs(sorted_idx(1:min(N_peaks, length(locs))));

    hold on;
    for j = 1:length(top_locs)
        text(freq_nozero(top_locs(j)), psd_nozero(top_locs(j)), ...
            sprintf('%.2f', period_nozero(top_locs(j))), ...
            'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'center', ...
            'FontSize', 8, 'Color', 'red', 'FontWeight', 'bold');
    end
    hold off;
end
